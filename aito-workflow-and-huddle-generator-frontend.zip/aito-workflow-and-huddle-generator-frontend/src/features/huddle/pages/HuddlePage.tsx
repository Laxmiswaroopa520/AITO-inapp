import { useEffect, useMemo, useState } from "react";
import { useAtom } from "jotai";
import { useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, Box, CalendarDays, CheckCircle2, ChevronRight, HelpCircle, Home, Library, Users, X } from "lucide-react";
import { useNavigate } from "react-router";
import { cn } from "@/lib/utils";
import { useApiClient } from "@/api/useApiClient";
import { getHuddleById } from "../api";
import { huddleQueryKeys } from "../hooks/huddleQueryKeys";
import { HuddleAudienceSelect } from "../components/audience";
import { HuddleCatalog, HuddleDownvoteDialog, HuddleFilterBar } from "../components/catalog";
import { HuddleDetailPanel, HuddleGuideImageDialog, HuddlePreviewDialog, HuddleWorkspace } from "../components/generated";
import { MeetCoachDialog } from "../components/coach";
import { HuddleInABoxDialog } from "../components/huddleInABox";
import { HuddleOnboardingExperience } from "../components/onboarding";
import { HuddleResourcesRepository } from "../components/resources";
import { RecommendedPath } from "../components/progress";
import { downloadHtmlFile } from "../exports/html/htmlTemplate";
import huddleInABoxTemplateHtml from "@/assets/HuddleInBox/HuddleInABox_Template 1.html?raw";
import facilitatorGuideImage from "@/assets/huddle/guides/facilitator-guide.png";
import managerGuideImage from "@/assets/huddle/guides/manager-guide.png";
// ?url keeps this 5.9 MB file out of the JS bundle; it is only fetched when Week 1's HTML is downloaded.
import orientationPreviewHtmlUrl from "@/assets/huddle/orientation/orientation-preview.html?url";
import { useCompleteHuddleSession, useCustomLearningPlan, useHuddleAudienceRoles, useHuddleById, useHuddleCatalog, useHuddleSession, useHuddleVotes, useIncompleteHuddleSessions, useLegacyHuddlePlanMigration, useMyHuddlePlan, useResetHuddlePlan, useSaveHuddlePlan, useSaveHuddleSession, useSetHuddleActivityCompletion, useSetHuddleVote } from "../hooks";
import { huddlePersonaAtom, huddleViewModeAtom, selectedHuddleExternalIdAtom, selectedHuddleRoleExternalIdAtom, type HuddleViewMode } from "../store";
import type { HuddleCatalogItemResponse, HuddlePlanResponse, HuddlePresentationModel, HuddleVoteResponse } from "../types";
import type { HuddlePersona } from "../types/huddlePersona.types";
import { createHuddlePresentationModel } from "../mappers";

/**
 * The onboarding page has no tab of its own: it still opens first when a persona is chosen, and
 * the persona name in the breadcrumb leads back to it. While it shows, neither tab is highlighted.
 */
const NAVIGATION_ITEMS: { id: HuddleViewMode; label: string }[] = [
  { id: "guided", label: "Role Path" },
  { id: "evergreen", label: "All Topics" },
];

/**
 * The Launch Planner button is hidden for now. Its page and route still work; set this to true
 * to show the button in the Manager header again.
 */
const SHOW_LAUNCH_PLANNER = false;

const initialFilters = { focusArea: "", agent: "", sort: "default", search: "" };

type HuddleGuide = { title: string; imageSrc: string; fileName: string };

/** The one-page guide that goes with a Role Path week's HTML. Team Members get none. */
const HUDDLE_GUIDES: Partial<Record<HuddlePersona, HuddleGuide>> = {
  manager: { title: "How to Lead a Huddle - Manager Guide", imageSrc: managerGuideImage, fileName: "How to Lead a Huddle - Manager Guide.png" },
  facilitator: { title: "How a Huddle Runs - Facilitator Guide", imageSrc: facilitatorGuideImage, fileName: "How a Huddle Runs - Facilitator Guide.png" },
};

/**
 * Week 1's Frontier Accelerator Orientation ships as a hand-built HTML page instead of the generated
 * export. Matched on the name prefix because some roles title it "...Orientation for Account Executives".
 */
function isFrontierAcceleratorOrientation(huddle: HuddleCatalogItemResponse): boolean {
  return huddle.name.trim().toLowerCase().startsWith("frontier accelerator orientation");
}

function downloadAssetFile(href: string, fileName: string): void {
  const anchor = document.createElement("a");
  anchor.href = href;
  anchor.download = fileName;
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
}

export function HuddlePage() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useAtom(huddleViewModeAtom);
  const [selectedExternalId, setSelectedExternalId] = useAtom(selectedHuddleExternalIdAtom);
  const [selectedRoleExternalId, setSelectedRoleExternalId] = useAtom(selectedHuddleRoleExternalIdAtom);
  // All Topics can list several placements of the same topic (one per role), and a role's own
  // Role Path can also repeat a topic across two or three weeks (the same underlying workflow
  // staged over multiple placements). The topic id alone (selectedExternalId) can no longer say
  // which placement's content to open, so a card click -- from either tab -- also records its own
  // placementExternalId here, tagged to the topic id it belongs to so a value from a previous
  // selection is never reused for a different topic (see selectedPlacementExternalId below).
  const [selectedCatalogSelection, setSelectedCatalogSelection] = useState<{ externalId: string; placementExternalId: string | null } | null>(null);
  const selectFromCatalog = (externalId: string | null, placementExternalId: string | null = null) => {
    setSelectedExternalId(externalId);
    setSelectedCatalogSelection(externalId ? { externalId, placementExternalId } : null);
  };
  const [filters, setFilters] = useState(initialFilters);
  const [audienceRoleIds, setAudienceRoleIds] = useState<string[]>([]);
  // Tracks whether the reader has explicitly interacted with the All Topics audience
  // picker (a checkbox, Select All/Deselect All, or Clear). Until they have, an empty
  // audienceRoleIds means "nothing chosen yet" and the Role Path role is inherited below.
  // Once they have, an empty audienceRoleIds means "explicitly cleared" and must not be
  // re-inflated back to that inherited role -- see evergreenAudienceDisplayIds and
  // additionalRoleExternalId.
  const [audienceRoleIdsTouched, setAudienceRoleIdsTouched] = useState(false);
  /** The segment picked in the All Topics Segment dropdown, or null for All Segments. */
  const [evergreenSegment, setEvergreenSegment] = useState<string | null>(null);
  const handleAudienceRoleIdsChange = (ids: string[]) => {
    setAudienceRoleIdsTouched(true);
    setAudienceRoleIds(ids);
  };
  const [downvoteTarget, setDownvoteTarget] = useState<{ id: string; name: string } | null>(null);
  const [workspaceOpen, setWorkspaceOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [htmlExportPending, setHtmlExportPending] = useState(false);
  // Which Role Path week card is downloading its HTML, so only that card's button shows as busy.
  const [cardHtmlExportId, setCardHtmlExportId] = useState<string | null>(null);
  const [openGuide, setOpenGuide] = useState<HuddleGuide | null>(null);
  const queryClient = useQueryClient();
  const apiClient = useApiClient();
  const [coachContext, setCoachContext] = useState<{ externalId: string; name: string } | null>(null);
  const [persona, setPersona] = useAtom(huddlePersonaAtom);
  const [resourcesOpen, setResourcesOpen] = useState(false);
  const [huddleInABoxOpen, setHuddleInABoxOpen] = useState(false);
  const [exportPending, setExportPending] = useState(false);
  const [feedback, setFeedback] = useState<{ kind: "success" | "error"; message: string } | null>(null);

  // Mirrors the auto-dismissing acknowledgment pattern used elsewhere in Huddle (see
  // HuddleWorkspace's own `feedback` banner) so a download/export confirmation reads like a
  // toast instead of a banner the reader has to dismiss by hand.
  useEffect(() => {
    if (!feedback) return;
    const timer = window.setTimeout(() => setFeedback(null), 3200);
    return () => window.clearTimeout(timer);
  }, [feedback]);

  // Read directly from /api/roles instead of deriving from the catalog read: the audience
  // picker used to wait on every topic in the catalog just to list eight roles, so it could
  // not appear until the heaviest read on the page finished. See useHuddleAudienceRoles.
  const audienceRolesQuery = useHuddleAudienceRoles();
  const roles = useMemo(
    () => [...(audienceRolesQuery.data ?? [])].sort((left, right) => left.name.localeCompare(right.name)),
    [audienceRolesQuery.data],
  );

  const referenceCatalogQuery = useHuddleCatalog({});
  // "Only All Topics" opts out of the default projection below and back into the plain
  // Additional_Content-only set, scoped to the chosen audience or, while nothing has been
  // touched here yet, inherited from the reader's Role Path role -- exactly how All Topics
  // behaved before this default projection existed.
  const evergreenOnlyAllTopics = filters.sort === "only-all-topics";
  // All Topics silently inherits the Role Path role above when no explicit audience has
  // been chosen here (see additionalRoleExternalId). Reflect that inherited role in the picker
  // itself too, so it doesn't read "Select Audience" while a role is actually filtering the list.
  const evergreenAudienceDisplayIds = !audienceRoleIdsTouched && audienceRoleIds.length === 0 && selectedRoleExternalId ? [selectedRoleExternalId] : audienceRoleIds;
  const additionalRoleExternalId = (audienceRoleIds.length === 1 ? audienceRoleIds[0] : audienceRoleIdsTouched ? undefined : selectedRoleExternalId) ?? undefined;
  // A segment picked in All Topics with no role ticked filters strictly to that segment: only
  // cards whose roles include one of the segment's roles are shown (see evergreenCatalogData).
  // A segment with no Huddles of its own, such as Manager today, shows the empty state.
  const segmentRoleIds = useMemo(
    () => (evergreenSegment
      ? roles.filter((role) => (role.segment ?? "Other") === evergreenSegment && role.name !== "All Roles").map((role) => role.externalId)
      : []),
    [roles, evergreenSegment],
  );
  const segmentFilterActive = evergreenAudienceDisplayIds.length === 0 && segmentRoleIds.length > 0;
  const evergreenAudienceNote = null;
  //const evergreenAudienceNote = audienceRoleIds.length === 0 && selectedRoleExternalId ? "Matches your Role Path audience" : null;
  // All Topics' default projection: the Additional Content set plus the applicable Role
  // Path (weekly) topics -- every role's when no audience is showing as selected in the
  // picker, or just the audience role(s) shown as selected (evergreenAudienceDisplayIds
  // already carries the same inherited-role fallback the picker itself displays) once one
  // or more are. Leaving both params unset when no role is in scope lets the plain
  // "default catalog" projection -- already precomputed as that exact union -- come back
  // untouched. See localApiClient's huddleCatalog for the merge itself.
  const evergreenRolePathRoleIds = segmentFilterActive ? segmentRoleIds : evergreenAudienceDisplayIds;
  // Only the All Topics tab reads this. It used to run unconditionally alongside
  // referenceCatalogQuery on every visit to the Huddle page -- two full catalog reads in
  // parallel, competing for the same backend and database, before the reader had even chosen a
  // tab. Scoping it to its own tab (the same pattern already used for the Role Path query below)
  // halves that redundant load on first paint.
  const evergreenQuery = useHuddleCatalog(
    {
      additionalContentRoleExternalId: evergreenOnlyAllTopics ? additionalRoleExternalId : undefined,
      additionalContentOnly: evergreenOnlyAllTopics
        ? (additionalRoleExternalId === undefined ? true : undefined)
        : (evergreenRolePathRoleIds.length > 0 ? true : undefined),
      rolePathRoleExternalIds: !evergreenOnlyAllTopics && evergreenRolePathRoleIds.length > 0 ? evergreenRolePathRoleIds.join(",") : undefined,
      focusAreaExternalId: filters.focusArea || undefined,
      agentExternalId: filters.agent || undefined,
      search: filters.search || undefined,
      sort: (evergreenOnlyAllTopics ? "default" : (filters.sort || "default")) as "default" | "most-upvoted" | "role-relevance",
    },
    viewMode === "evergreen",
  );
  // All Topics only lists Huddles assigned to the audience in scope: the picked role(s), or every
  // role of the picked segment when no role is picked. A card stays when its roles include any of
  // them. "All Roles" is not listed on any card, so picking it leaves the list unrestricted.
  const evergreenFilterRoleIds = segmentFilterActive ? segmentRoleIds : evergreenAudienceDisplayIds;
  const evergreenCatalogData = useMemo(() => {
    if (!evergreenQuery.data || evergreenFilterRoleIds.length === 0) return evergreenQuery.data;
    const allRolesSelected = roles.some((role) => role.name === "All Roles" && evergreenFilterRoleIds.includes(role.externalId));
    if (allRolesSelected) return evergreenQuery.data;
    const inScope = new Set(evergreenFilterRoleIds);
    return evergreenQuery.data.filter((item) => item.roles.some((role) => inScope.has(role.externalId)));
  }, [evergreenQuery.data, evergreenFilterRoleIds, roles]);
  const incompleteSessionsQuery = useIncompleteHuddleSessions();
  const customLearningPlan = useCustomLearningPlan(persona);
  const personaLabel = persona === "team-member" ? "Team Member" : persona ? `${persona[0].toUpperCase()}${persona.slice(1)}` : null;
  const saveSessionMutation = useSaveHuddleSession();
  const activityCompletionMutation = useSetHuddleActivityCompletion();
  const completeSessionMutation = useCompleteHuddleSession();
  // Only the Role Path tab reads the Role Path. A role can legitimately have no weekly path,
  // and a role-path problem must not reach a tab that does not show it.
  const recommendedPathQuery = useMyHuddlePlan(selectedRoleExternalId, viewMode === "guided");
  // Which placement to open. The same topic sits on several role paths with different activities,
  // so the detail read has to name one, otherwise the API aggregates every role: a topic on five
  // placements comes back with fifteen phases. Role Path and catalog cards both carry the id.
  const selectedPlacementExternalId = useMemo(() => {
    if (!selectedExternalId) return null;
    if (selectedCatalogSelection?.externalId === selectedExternalId) return selectedCatalogSelection.placementExternalId;
    const fromPath = recommendedPathQuery.data?.items.find((item) => item.huddle.externalId === selectedExternalId);
    if (fromPath?.huddle.placementExternalId) return fromPath.huddle.placementExternalId;
    const fromCatalog = evergreenQuery.data?.find((item) => item.externalId === selectedExternalId);
    return fromCatalog?.placementExternalId ?? null;
  }, [selectedExternalId, recommendedPathQuery.data, evergreenQuery.data, selectedCatalogSelection]);
  const detailQuery = useHuddleById(selectedExternalId, selectedPlacementExternalId);
  // The session is scoped to the same placement. Without it the API counts every activity on the
  // topic across every role path, which is where "3 of 22" came from on a five-activity Huddle.
  const sessionQuery = useHuddleSession(selectedExternalId, selectedPlacementExternalId);
  const savePlanMutation = useSaveHuddlePlan();
  const resetPlanMutation = useResetHuddlePlan();
  const votesQuery = useHuddleVotes();
  const voteMutation = useSetHuddleVote();
  useLegacyHuddlePlanMigration(selectedRoleExternalId, recommendedPathQuery.data, referenceCatalogQuery.data);

  // The audience list has its own pending and error states now, independent of the catalog.
  const rolesLoading = audienceRolesQuery.isPending;
  const rolesErrorMessage = audienceRolesQuery.isError
    ? "Audience roles could not be loaded. Refresh to try again."
    : null;

  const options = useMemo(() => {
    const focusAreas = new Map<string, string>();
    const agents = new Map<string, string>();
    referenceCatalogQuery.data?.forEach((huddle) => {
      if (huddle.focusAreaExternalId && huddle.focusAreaName) focusAreas.set(huddle.focusAreaExternalId, huddle.focusAreaName);
      [...huddle.primaryAgents, ...huddle.secondaryAgents].forEach((agent) => agents.set(agent.externalId, agent.name));
    });
    const sortOptions = (entries: [string, string][]) => entries.sort((left, right) => left[1].localeCompare(right[1])).map(([value, label]) => ({ value, label }));
    return { focusAreas: sortOptions([...focusAreas]), agents: sortOptions([...agents]) };
  }, [referenceCatalogQuery.data]);

  const filterKey = `${evergreenSegment ?? ""}|${audienceRoleIds.join(",")}|${filters.focusArea}|${filters.agent}|${filters.sort}|${filters.search}`;
  const votes = useMemo(() => new Map<string, HuddleVoteResponse>((votesQuery.data ?? []).map((vote) => [vote.huddleExternalId, vote])), [votesQuery.data]);
  const presentationAudience = useMemo(() => {
    const roleExternalId = viewMode === "guided" ? selectedRoleExternalId : audienceRoleIds.length === 1 ? audienceRoleIds[0] : null;
    return { roleExternalId, roleName: roles.find((role) => role.externalId === roleExternalId)?.name ?? null };
  }, [audienceRoleIds, roles, selectedRoleExternalId, viewMode]);
  const presentationModel = useMemo(() => detailQuery.data ? createHuddlePresentationModel(detailQuery.data, presentationAudience) : null, [detailQuery.data, presentationAudience]);
  const sessionError = sessionQuery.error ?? saveSessionMutation.error ?? activityCompletionMutation.error ?? completeSessionMutation.error;
  const saveSession = (currentPhaseExternalId: string | null, facilitatorNotes: string | null) => saveSessionMutation.mutateAsync({ externalId: selectedExternalId!, request: { currentPhaseExternalId, facilitatorNotes, rowVersion: sessionQuery.data?.rowVersion ?? null }, placementExternalId: selectedPlacementExternalId });
  const setActivityCompletion = async (activityExternalId: string, isCompleted: boolean, currentPhaseExternalId: string | null, facilitatorNotes: string | null) => {
    const current = sessionQuery.data ?? await saveSessionMutation.mutateAsync({ externalId: selectedExternalId!, request: { currentPhaseExternalId, facilitatorNotes, rowVersion: null }, placementExternalId: selectedPlacementExternalId });
    return activityCompletionMutation.mutateAsync({ externalId: selectedExternalId!, activityExternalId, request: { isCompleted, rowVersion: current.rowVersion }, placementExternalId: selectedPlacementExternalId });
  };
  const completeSession = () => completeSessionMutation.mutateAsync({ externalId: selectedExternalId!, request: { rowVersion: sessionQuery.data!.rowVersion }, placementExternalId: selectedPlacementExternalId });
  const continueLearning = (externalId: string) => { setSelectedExternalId(externalId); setSelectedCatalogSelection(null); setWorkspaceOpen(true); };
  const savePlan = (plan: HuddlePlanResponse) => savePlanMutation.mutate({ optimisticPlan: plan, request: { roleExternalId: plan.roleExternalId, rowVersion: recommendedPathQuery.data?.rowVersion ?? null, items: plan.items.map((item) => ({ week: item.week, huddleExternalId: item.huddle.externalId, placementExternalId: item.huddle.placementExternalId ?? null })) } });
  const resetPlan = () => {
    const plan = recommendedPathQuery.data;
    if (!plan) return;
    const items = plan.items.map((item) => ({ ...item, isCustomized: false, huddle: referenceCatalogQuery.data?.find((candidate) => candidate.externalId === item.recommendedHuddleExternalId) ?? item.huddle }));
    resetPlanMutation.mutate({ roleExternalId: plan.roleExternalId, optimisticPlan: { ...plan, rowVersion: null, isCustomized: false, items } });
  };
  const changeViewMode = (mode: HuddleViewMode) => { setViewMode(mode); setSelectedExternalId(null); setSelectedCatalogSelection(null); setWorkspaceOpen(false); setPreviewOpen(false); };
  const selectPersona = (nextPersona: HuddlePersona) => {
    setPersona(nextPersona);
    selectFromCatalog(null);
    window.requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "smooth" }));
  };
  const changePersona = () => {
    setPersona(null);
    selectFromCatalog(null);
    setViewMode("orientation");
    window.requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "smooth" }));
  };
  const changeFilter = (name: "focusArea" | "agent" | "sort" | "search", value: string) => setFilters((current) => ({ ...current, [name]: value }));
  const setVote = (externalId: string, value: -1 | 1 | null) => {
    if (value === -1) {
      const huddle = referenceCatalogQuery.data?.find((item) => item.externalId === externalId);
      setDownvoteTarget({ id: externalId, name: huddle?.name ?? "this Huddle" });
      return;
    }
    voteMutation.mutate({ externalId, request: value === null ? null : { value, downvoteReasons: null, comment: null } });
  };

  const downloadHuddleInABoxTemplate = () => {
    setFeedback(null);
    try {
      downloadHtmlFile(huddleInABoxTemplateHtml, "Huddle in a Box.html");
      setFeedback({ kind: "success", message: "Huddle in a Box downloaded successfully." });
    } catch (error) {
      setFeedback({ kind: "error", message: error instanceof Error ? error.message : "Unable to download Huddle in a Box." });
    }
  };
  /** Returns whether the HTML downloaded, so callers can follow up only on success. */
  const downloadHuddleHtml = async (loadModel: () => Promise<HuddlePresentationModel>): Promise<boolean> => {
    setFeedback(null);
    try {
      const [{ exportHuddleHtml }, model] = await Promise.all([import("../exports/html"), loadModel()]);
      exportHuddleHtml(model);
      setFeedback({ kind: "success", message: "HTML downloaded successfully." });
      return true;
    } catch (error) {
      setFeedback({ kind: "error", message: error instanceof Error ? error.message : "Unable to download the HTML." });
      return false;
    }
  };
  const exportSelectedHuddleHtml = async () => {
    if (!presentationModel || htmlExportPending) return;
    setHtmlExportPending(true);
    try {
      await downloadHuddleHtml(async () => presentationModel);
    } finally {
      setHtmlExportPending(false);
    }
  };
  // Role Path week cards download without being selected first, so the detail is read through the
  // same cached query the detail panel uses (same key, so a card that was already opened is reused).
  const exportRolePathHuddleHtml = async (huddle: HuddleCatalogItemResponse) => {
    if (cardHtmlExportId) return;
    setCardHtmlExportId(huddle.externalId);
    const placementExternalId = huddle.placementExternalId ?? null;
    try {
      let downloaded: boolean;
      if (isFrontierAcceleratorOrientation(huddle)) {
        setFeedback(null);
        downloadAssetFile(orientationPreviewHtmlUrl, "orientation-preview.html");
        setFeedback({ kind: "success", message: "HTML downloaded successfully." });
        downloaded = true;
      } else {
        downloaded = await downloadHuddleHtml(async () => {
          const detail = await queryClient.fetchQuery({
            queryKey: huddleQueryKeys.detail(huddle.externalId, placementExternalId),
            queryFn: ({ signal }) => getHuddleById(apiClient, huddle.externalId, placementExternalId, signal),
            staleTime: 5 * 60 * 1000,
          });
          return createHuddlePresentationModel(detail, presentationAudience);
        });
      }
      const guide = persona ? HUDDLE_GUIDES[persona] : undefined;
      if (downloaded && guide) {
        downloadAssetFile(guide.imageSrc, guide.fileName);
        setOpenGuide(guide);
      }
    } finally {
      setCardHtmlExportId(null);
    }
  };
  const exportSelectedHuddlePowerPoint = async () => {
    if (!presentationModel || exportPending) return;
    setExportPending(true);
    try {
      const { exportHuddlePowerPoint } = await import("../exports/powerpoint");
      await exportHuddlePowerPoint(presentationModel);
    } finally {
      setExportPending(false);
    }
  };

  const detailPanel = <HuddleDetailPanel data={detailQuery.data} isLoading={detailQuery.isLoading} error={detailQuery.error} hasSelection={Boolean(selectedExternalId)} facilitatorHub={persona === "facilitator"} exportPending={exportPending} onRetry={() => void detailQuery.refetch()} onOpenWorkspace={() => setWorkspaceOpen(true)} onPreview={() => setPreviewOpen(true)} onExportHtml={() => void exportSelectedHuddleHtml()} onExportPowerPoint={() => void exportSelectedHuddlePowerPoint()} onMeetCoach={() => detailQuery.data && setCoachContext({ externalId: detailQuery.data.externalId, name: detailQuery.data.name })} />;

  return (
    <div className="mx-auto max-w-[1540px] space-y-6 p-4 [font-family:var(--aito-font-sans)] lg:p-6">
      <header className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          {persona && (
            <nav
              data-tour="huddle-breadcrumb"
              aria-label="Huddle breadcrumb"
              className="mb-1.5 flex min-w-0 items-center gap-1 text-sm font-medium"
            >
              <button
                type="button"
                onClick={changePersona}
                title="Back to the Huddle landing page"
                className="inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[#0F6CBD] transition-colors hover:bg-[#E8F2FF] hover:underline"
              >
                <Home className="h-3.5 w-3.5" aria-hidden="true" />
                Home
              </button>

              <ChevronRight
                className="h-3.5 w-3.5 shrink-0 text-muted-foreground/50"
                aria-hidden="true"
              />

              {viewMode === "orientation" ? (
                <span
                  className="px-1.5 py-0.5 text-muted-foreground"
                  aria-current="page"
                >
                  {personaLabel}
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => changeViewMode("orientation")}
                  title={`Back to ${personaLabel} home`}
                  className="truncate rounded-md px-1.5 py-0.5 text-[#0F6CBD] transition-colors hover:bg-[#E8F2FF] hover:underline"
                >
                  {personaLabel}
                </button>
              )}
            </nav>
          )}

          <div className="mb-2 flex items-center gap-3">
            <span className="rounded-xl bg-[#E8F2FF] p-2">
              <Users className="h-6 w-6 text-[#0F6CBD]" />
            </span>

            <h1 className="text-2xl font-bold lg:text-3xl">
              {persona ? personaLabel : "Huddles"}
            </h1>
          </div>

          <p className="text-muted-foreground">
            {persona
              ? "Discover and run guided Huddles that help your team apply AI to real workflows."
              : "Build AI fluency through guided conversations, practical activities, and shared learning."}
          </p>
        </div>

        <div className="flex flex-nowrap shrink-0 items-center gap-1.5">
          {/* Same action as the header's "?" icon, placed where a reader who is unsure where to go will see it. */}
          <span className="group relative inline-flex shrink-0">
            <button
              type="button"
              onClick={() => window.dispatchEvent(new Event("aito:start-layout-tour"))}
              className="inline-flex h-10 items-center rounded-lg border bg-white px-3 text-sm font-semibold hover:bg-muted"
            >
              <HelpCircle className="mr-2 h-4 w-4" />
              Help and tips
            </button>

            <span
              role="tooltip"
              className="pointer-events-none absolute left-0 top-full z-20 mt-2 w-64 rounded-lg border bg-white p-2.5 text-xs font-medium leading-4 text-[#242424] opacity-0 shadow-lg transition-opacity duration-150 group-hover:opacity-100"
            >
              Not sure where to go? Take a quick tour of this page.
            </span>
          </span>

          <span className="group relative inline-flex shrink-0">
            <button
              type="button"
              data-tour="huddle-in-a-box"
              onClick={() => setHuddleInABoxOpen(true)}
              className="inline-flex h-10 items-center rounded-lg border border-[#0A6BBA] bg-white px-3 text-sm font-semibold text-[#0A6BBA] hover:bg-[#E2F1F9]"
            >
              <Box className="mr-2 h-4 w-4" />
              Create your own huddle
            </button>

            <span
              role="tooltip"
              className="pointer-events-none absolute left-0 top-full z-20 mt-2 w-64 rounded-lg border bg-white p-2.5 text-xs font-medium leading-4 text-[#242424] opacity-0 shadow-lg transition-opacity duration-150 group-hover:opacity-100"
            >
              Not finding the role, workflow, practice, or tool you're looking for? Try creating your own huddle content!
            </span>
          </span>

          {SHOW_LAUNCH_PLANNER && persona === "manager" && (
            <button
              type="button"
              data-tour="huddle-launch-planner"
              onClick={() => navigate("/huddle/launch-planner")}
              className="inline-flex h-10 items-center rounded-lg border border-[#C7C7C7] bg-[#F0F0F0] px-3 text-sm font-semibold text-[#616161] hover:bg-[#E6E6E6] shrink-0"
            >
              <CalendarDays className="mr-2 h-4 w-4" />
              Launch Planner
            </button>
          )}

          <button
            type="button"
            data-tour="huddle-resources"
            onClick={() => setResourcesOpen(true)}
            className="inline-flex h-10 items-center rounded-lg border bg-white px-3 text-sm font-semibold hover:bg-muted shrink-0"
          >
            <Library className="mr-2 h-4 w-4" />
            Resources
          </button>
        </div>
      </header>
      {feedback && (
        <div
          role="status"
          className={cn(
            "fixed bottom-6 right-6 z-[110] flex max-w-sm items-start gap-2 rounded-lg border p-3 text-sm shadow-lg",
            feedback.kind === "success" ? "border-green-200 bg-green-50 text-green-900" : "border-red-200 bg-red-50 text-red-900",
          )}
        >
          {feedback.kind === "success" ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
          ) : (
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
          )}
          <span className="flex-1">{feedback.message}</span>
          <button type="button" onClick={() => setFeedback(null)} aria-label="Dismiss notification" className="shrink-0 opacity-70 hover:opacity-100">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
      {persona && <div className="space-y-4"><nav data-tour="huddle-sections" aria-label="Huddle sections" className="inline-flex flex-wrap items-center gap-1 rounded-xl border border-border/80 bg-muted/40 p-1.5 shadow-sm">{NAVIGATION_ITEMS.map((item) => <button key={item.id} type="button" onClick={() => changeViewMode(item.id)} className={cn("rounded-lg px-5 py-2 text-sm font-semibold transition-all duration-200", viewMode === item.id ? "border border-[#0F6CBD] bg-[#0F6CBD] text-white shadow-md shadow-[#0F6CBD]/20" : "text-muted-foreground hover:bg-white/80 hover:text-foreground")}>{item.label}</button>)}</nav>{viewMode === "guided" && <div data-tour="huddle-audience"><HuddleAudienceSelect mode="single" roles={roles} loading={rolesLoading} errorMessage={rolesErrorMessage} selectedIds={selectedRoleExternalId ? [selectedRoleExternalId] : []} onChange={(selectedIds) => { setSelectedRoleExternalId(selectedIds[0] ?? null); setSelectedExternalId(null); setSelectedCatalogSelection(null); }} /></div>}{viewMode === "evergreen" && <div data-tour="huddle-filters"><HuddleFilterBar filters={filters} options={options} roles={roles} rolesLoading={rolesLoading} rolesErrorMessage={rolesErrorMessage} audienceRoleIds={evergreenAudienceDisplayIds} onAudienceChange={handleAudienceRoleIdsChange} audienceSegment={evergreenSegment} onAudienceSegmentChange={setEvergreenSegment} audienceNote={evergreenAudienceNote} onFilterChange={changeFilter} /></div>}</div>}

      {viewMode === "orientation" && <HuddleOnboardingExperience key={persona ?? "choose-experience"} persona={persona} onSelectPersona={selectPersona} onChangePersona={changePersona} onStartRolePath={() => changeViewMode("guided")} onAdditionalTopics={() => changeViewMode("evergreen")} />}
      {persona && viewMode !== "orientation" && <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_420px]"><div data-tour="huddle-list" className="min-w-0">{viewMode === "guided" ? <RecommendedPath data={recommendedPathQuery.data} roleName={presentationAudience.roleName} catalog={referenceCatalogQuery.data ?? []} isLoading={recommendedPathQuery.isLoading} error={recommendedPathQuery.error} mutationError={savePlanMutation.error ?? resetPlanMutation.error} selectedExternalId={selectedExternalId} selectedPlacementExternalId={selectedPlacementExternalId} hasRole={Boolean(selectedRoleExternalId)} votes={votes} votePending={voteMutation.isPending} savePending={savePlanMutation.isPending || resetPlanMutation.isPending} onSelect={selectFromCatalog} onVote={setVote} htmlExportExternalId={cardHtmlExportId} onExportHtml={(huddle) => void exportRolePathHuddleHtml(huddle)} onSave={savePlan} onReset={resetPlan} onRetry={() => void recommendedPathQuery.refetch()} /> : <HuddleCatalog data={evergreenCatalogData} isLoading={evergreenQuery.isLoading} error={evergreenQuery.error} selectedExternalId={selectedExternalId} selectedPlacementExternalId={selectedPlacementExternalId} audienceRoleIds={evergreenOnlyAllTopics ? audienceRoleIds : []} filterKey={filterKey} filtersActive={Boolean(filters.focusArea || filters.agent || filters.search)} votes={votes} votePending={voteMutation.isPending} continueLearning={incompleteSessionsQuery.data} plan={customLearningPlan} planAudienceLabel={personaLabel} onSelect={selectFromCatalog} onVote={setVote} onRetry={() => void evergreenQuery.refetch()} onContinue={continueLearning} onCloseDetails={() => selectFromCatalog(null)} onCreateOwnHuddle={() => setHuddleInABoxOpen(true)} htmlExportExternalId={cardHtmlExportId} onExportHtml={(huddle) => void exportRolePathHuddleHtml(huddle)} />}</div><div data-tour="huddle-detail">{detailPanel}</div></div>}
      {openGuide && <HuddleGuideImageDialog title={openGuide.title} imageSrc={openGuide.imageSrc} onClose={() => setOpenGuide(null)} />}
      {downvoteTarget && <HuddleDownvoteDialog huddleName={downvoteTarget.name} onCancel={() => setDownvoteTarget(null)} onSubmit={(downvoteReasons, comment) => { voteMutation.mutate({ externalId: downvoteTarget.id, request: { value: -1, downvoteReasons, comment } }); setDownvoteTarget(null); }} />}
      {workspaceOpen && presentationModel && !sessionQuery.isLoading && <HuddleWorkspace key={presentationModel.identity.externalId} model={presentationModel} session={sessionQuery.data} sessionLoading={sessionQuery.isLoading} sessionError={sessionError} mutationPending={saveSessionMutation.isPending || activityCompletionMutation.isPending || completeSessionMutation.isPending} onRefreshSession={async () => (await sessionQuery.refetch()).data} onSaveSession={saveSession} onSetActivityCompletion={setActivityCompletion} onCompleteSession={completeSession} onMeetCoach={() => setCoachContext({ externalId: presentationModel.identity.externalId, name: presentationModel.identity.name })} onPreviewSlides={() => setPreviewOpen(true)} onClose={() => setWorkspaceOpen(false)} />}
      {previewOpen && presentationModel && <HuddlePreviewDialog open model={presentationModel} onClose={() => setPreviewOpen(false)} />}
      {coachContext && <MeetCoachDialog open huddleExternalId={coachContext.externalId} huddleName={coachContext.name} onClose={() => setCoachContext(null)} />}
      <HuddleResourcesRepository open={resourcesOpen} catalog={referenceCatalogQuery.data ?? []} onClose={() => setResourcesOpen(false)} />
      <HuddleInABoxDialog open={huddleInABoxOpen} onClose={() => setHuddleInABoxOpen(false)} onDownload={downloadHuddleInABoxTemplate} />
    </div>
  );
}
