import {
  ArrowRight, BookOpen, CheckCircle2, ChevronRight,
  Compass, Lightbulb, RefreshCw, Sparkles, Target,
  TrendingUp, Users, ShieldCheck, Presentation, Check,
  Repeat2, FileImage, CalendarDays,
} from 'lucide-react';
import { useState, type ElementType } from 'react';
import { motion } from 'motion/react';
import { Button } from '@/components/ui/button';

import managerImage from '@/assets/huddle/onboarding/manager.avif';
import facilitatorImage from '@/assets/huddle/onboarding/facilitator.avif';
import memberImage from '@/assets/huddle/onboarding/team-member.avif';
import researcherLogo from '@/assets/agents/required-researcher.png';
import coworkLogo from '@/assets/agents/required-cowork.png';
import scoutLogo from '@/assets/agents/required-scout.png';
import salesAgentLogo from '@/assets/agents/required-sales-agent.png';
import agentJLogo from '@/assets/agents/required-agent-j.png';
import managerGuideImage from '@/assets/huddle/guides/manager-guide.png';
import facilitatorGuideImage from '@/assets/huddle/guides/facilitator-guide.png';

import { HuddleGuideImageDialog } from '../generated/HuddleGuideImageDialog';
import { HuddleResourcesSection } from './HuddleResourcesSection';
import type { HuddlePersona } from '../../types/huddlePersona.types';

/** The one-page guide behind the onboarding "HTML Walkthrough" button. Team Members get none. */
const WALKTHROUGH_GUIDES: Partial<Record<HuddlePersona, { title: string; imageSrc: string; fileName: string }>> = {
  manager: { title: 'How to Lead a Huddle - Manager Guide', imageSrc: managerGuideImage, fileName: 'How to Lead a Huddle - Manager Guide.png' },
  facilitator: { title: 'How a Huddle Runs - Facilitator Guide', imageSrc: facilitatorGuideImage, fileName: 'How a Huddle Runs - Facilitator Guide.png' },
};

interface HuddleOnboardingExperienceProps {
  persona: HuddlePersona | null;
  onSelectPersona: (persona: HuddlePersona) => void;
  onStartRolePath: () => void;
  onAdditionalTopics: () => void;
  onChangePersona: () => void;
}

// Locally bundled placeholder illustrations -- replace with approved brand photography when
// available. These exist only so the app never depends on an externally hosted image
// (previously images.unsplash.com); no network request is made to render them.
const IMAGES = {
  manager: managerImage,
  facilitator: facilitatorImage,
  member: memberImage,
};

const personas = [
  {
    id: 'manager' as const, icon: Target, title: 'Manager', headline: 'Lead AI adoption across your team', image: IMAGES.manager,
    body: 'Set direction, shape learning priorities, and help team members turn AI practice into stronger team habits.',
    helps: ['Select a role-based learning path', 'Customize recommended Huddles', 'Build and export a team learning plan', 'Reinforce adoption through team rhythm'],
    success: 'Your team applies AI to real workflows and brings back examples that improve how work gets done.',
    cta: 'Open Manager View', accent: '#0A6BBA',
  },
  {
    id: 'facilitator' as const, icon: Presentation, title: 'Facilitator', headline: 'Run practical Huddles with confidence', image: IMAGES.facilitator,
    body: 'Prepare, guide, capture, and follow up on Huddles that connect AI to the work team members do every day.',
    helps: ['Prepare for a Huddle', 'Guide the conversation', 'Use recommended prompts', 'Capture notes and actions', 'Export session materials'],
    success: 'Team members practice with real prompts and leave with one practical commitment they can apply.',
    cta: 'Open Facilitator View', accent: '#2A446F',
  },
  {
    id: 'team-member' as const, icon: Users, title: 'Team Member', headline: 'Build AI habits through real work', image: IMAGES.member,
    body: 'Follow a role-based path, practice AI in daily workflows, explore all topics, and share what works.',
    helps: ['Understand the learning journey', 'Complete role-based Huddles', 'Practice AI with real workflows', 'Explore all topics', 'Build repeatable AI habits'],
    success: 'You know when to use the right AI experiences and can apply them to everyday work with confidence.',
    cta: 'Start Learning Journey', accent: '#287C70',
  },
];

const whyItExists: Array<[string, string, ElementType]> = [
  ['Increase AI confidence', 'Help team members use AI comfortably and responsibly in their work.', Sparkles],
  ['Build practical habits', 'Move beyond awareness into repeatable actions and applied skills.', Target],
  ['Learn across teams', 'Share successful approaches, examples, and practical lessons with peers.', Users],
  ['Sustain adoption', 'Create momentum that continues beyond a single Huddle.', TrendingUp],
];

const readiness = [
  ['Verify access to required tools', 'Step 1'],
  ['Top 5 MCAPS Agents training', 'Step 2 · Includes relevant recommended resources'],
  ['Review motion expectations', 'Step 3'],
  ['Watch the motion overview', 'Step 4'],
];

const successSignals: Array<[string, string, ElementType]> = [
  ['Use AI regularly', 'Integrate AI into day-to-day work.', Sparkles],
  ['Improve efficiency', 'Reduce friction across common workflows.', TrendingUp],
  ['Share what works', 'Bring practical examples back to peers.', Users],
  ['Build confidence', 'Use AI responsibly in real scenarios.', ShieldCheck],
  ['Create repeatable habits', 'Continue improving after the Huddle.', RefreshCw],
];

const rhythm = [
  ['Reflect', 'Share wins, lessons, and friction points.'],
  ['Frame', 'Connect the topic to the workflow and outcome.'],
  ['Discuss', 'Surface questions, blockers, and peer insights.'],
  ['Practice', 'Try a prompt, tool, or workflow pattern.'],
  ['Commit', 'Choose one practical action for this week.'],
  ['Bring Back', 'Return with evidence, learning, or a result.'],
];

const topAgents = [
  { name: 'Researcher', label: 'Research & validate', description: 'Build grounded insights through focused research and analysis.', logo: researcherLogo },
  { name: 'Cowork', label: 'Create & orchestrate', description: 'Turn complex work into structured outputs and actionable next steps.', logo: coworkLogo },
  { name: 'Scout', label: 'Monitor & discover', description: 'Surface relevant signals, changes and information worth exploring.', logo: scoutLogo },
  { name: 'Sales Agent', label: 'Plan & progress', description: 'Support customer, account and opportunity workflows.', logo: salesAgentLogo },
  { name: 'Agent J.ai', label: 'Prepare & practice', description: 'Prepare and practice for important customer conversations.', logo: agentJLogo },
];

const journeySteps: Array<[string, string, string, string, string, ElementType, string]> = [
  ['01', 'Onboarding/Orientation', 'Understand the motion, Think Feel Do, and how your role uses Huddles.', '15 min', 'Ready to enter your role path.', Compass, '#E2F1F9'],
  ['02', 'Role Path', 'Follow a recommended sequence of Huddles aligned to your role.', '7 Huddles', 'Build repeatable workflow habits.', Target, '#E3F1ED'],
  ['03', 'All Topics', 'Explore more workflows and build a custom plan around what matters next.', 'Flexible', 'Extend fluency beyond the core path.', BookOpen, '#F0E9E3'],
];

const personaOnboarding = {
  manager: {
    title: 'Manager Onboarding', subtitle: 'Lead your team’s Huddle and turn AI practice into real work.',
    role: 'Set the rhythm, connect each Huddle to your team’s priorities, and create the conditions for people to experiment, learn, and apply AI in their day-to-day work.',
    heroCta: 'Explore Role Path',
    cards: [
      ['Set the direction', ['Choose the right role path', 'Connect Huddles to team priorities', 'Explain why the learning matters']],
      ['Shape the plan', ['Review recommended Huddles', 'Customize the sequence if needed', 'Add all topics for your team']],
      ['Reinforce the habit', ['Encourage team members to bring back examples', 'Create repeatable AI behaviors', 'Keep the focus on real work']],
      ['Export and share', ['Export role and custom learning plans', 'Share the plan with facilitators and team members']],
    ],
    primary: 'Go to Role Path',
  },
  facilitator: {
    title: 'Facilitator Onboarding', subtitle: 'Prepare, guide, and run practical Huddles that help team members apply AI to real work.',
    role: 'As a Facilitator, make each Huddle practical, focused, and collaborative. Use the app to prepare the session, guide discussion, use prompts, capture notes, and create useful follow-up materials.',
    heroCta: 'Explore Role Path',
    cards: [
      ['Prepare the session', ['Select the Huddle topic', 'Review the outcome and activities', 'Use the facilitator workspace to prepare']],
      ['Guide the conversation', ['Use the Huddle flow', 'Facilitate around real work', 'Connect AI to workflow outcomes']],
      ['Practice with prompts', ['Use recommended prompts', 'Copy prompts into the relevant AI experience', 'Encourage experimentation and sharing']],
      ['Capture and follow up', ['Add facilitator notes', 'Save progress', 'Export HTML or PowerPoint materials where available']],
    ],
    primary: 'Open Role Path',
  },
  'team-member': {
    title: 'Team Member Orientation', subtitle: 'Bring your work. Try something. Share what happens.',
    role: 'Huddles are a space to experiment with AI using the work you are already doing. No AI expertise is required. Bring real work, participate, apply what is useful, and share what you learn.',
    heroCta: 'Explore Role Path',
    cards: [
      ['Understand the journey', ['Start with orientation', 'Follow the role path', 'Continue through all topics']],
      ['Join Huddles', ['Take part in weekly discussions', 'Share wins and friction points', 'Learn from team examples']],
      ['Practice AI in real work', ['Try recommended prompts', 'Apply AI to common workflows', 'Bring back examples and outcomes']],
      ['Build lasting habits', ['Repeat what works', 'Save useful prompts', 'Use AI as part of everyday work']],
    ],
    primary: 'Start Role Path',
  },
} as const;

// Shown on every role's onboarding page in the Success looks like panel.
const teamRhythmSuccess = ['The team understands why the Huddle matters', 'Huddles stay connected to real priorities', 'The weekly cadence remains protected', 'Team members bring back practical examples', 'Useful practices continue beyond the initial motion'];

// Each role's onboarding page shows its action plan: a countdown or milestone timeline, then the rhythm around each Huddle.
interface RoleActionPlan {
  eyebrow: string;
  title: string;
  note: string;
  steps: Array<{ label: string; items: string[] }>;
  phases: Array<{ phase: string; items: string[] }>;
}

const roleActionPlans: Record<HuddlePersona, RoleActionPlan> = {
  manager: {
    eyebrow: 'Get ready',
    title: 'Manager Action Plan: What you will do and when',
    note: '“T-” labels mark milestones in the weeks counting down to the first Huddle (Week 1); “activation” refers to the 8-week Huddle motion and the period after it.',
    steps: [
      { label: 'T-3 Weeks', items: ['Confirm who will be in your Huddle.', 'Connect with your Facilitator.', 'Raise scheduling or coverage concerns.', 'Begin Onboarding.'] },
      { label: 'T-2 Weeks', items: ['Complete Manager onboarding.', 'Introduce the motion to your team in language that feels relevant to their work.', 'Reinforce the baseline survey.'] },
      { label: 'T-1 Week', items: ['Schedule the recurring Huddles & confirm the right people and Facilitator are included.', 'Make sure recording and transcript steps are set up and understood.', 'Attend 1st Community Call.'] },
    ],
    phases: [
      { phase: 'Before each Huddle', items: ['Meet with your Facilitator.', 'Agree on the team-specific why, a real-work example, and what you hope people will try or learn.'] },
      { phase: 'During each Huddle', items: ['Open with the why.', 'Participate with curiosity & encourage team to participate.', 'Connect the conversation to outcomes.'] },
      { phase: 'After each Huddle', items: ['Reinforce go-dos.', 'Remove blockers.', 'Make sure transcript is available.', 'Share valuable insights & improvements.'] },
      { phase: 'After Week 8', items: ['Encourage team to complete impact survey.', 'Participate in retrospective.', 'Confirm next steps for ongoing rhythm.'] },
    ],
  },
  facilitator: {
    eyebrow: 'Get ready',
    title: 'Facilitator Action Plan',
    note: '“T-” labels mark milestones in the weeks counting down to the first Huddle (Week 1); “activation” refers to the 8-week Huddle motion and the period after it.',
    steps: [
      { label: 'T-3 Weeks', items: ['Connect with your Manager.', 'Flag access, scheduling or preparation needs early.', 'Begin Onboarding.'] },
      { label: 'T-2 Weeks', items: ['Complete Facilitator onboarding.', 'Get comfortable with the process: Experience Cards, discussion flow, feedback form, Manager/Facilitator Community Calls & support, etc.'] },
      { label: 'T-1 Week', items: ['Confirm access to topics, tools, materials and team context.', 'Meet with Manager to shape the first session.', 'Rehearse the workflow & attend 1st Community Call.'] },
    ],
    phases: [
      { phase: 'Before each Huddle', items: ['Review the topic and what the team tried last time.', 'Choose a real-work scenario.', 'Confirm with Manager on the opening, flow, and go-dos.'] },
      { phase: 'During each Huddle', items: ['Always include the week’s Huddle topic in the chat.', 'Invite people to try and share & make room for every voice.', 'Stay curious about friction & keep the focus on real work.', 'Ask the usefulness question.', 'Close with go-dos.'] },
      { phase: 'After each Huddle', items: ['Partner with the Manager on follow-up.', 'Share friction or ideas via the feedback form.', 'Leverage Manager/Facilitator Community Calls and coaching tips.'] },
      { phase: 'After Week 8', items: ['Share what you learned in the retrospective.', 'Help Manager decide how to continue.'] },
    ],
  },
  'team-member': {
    eyebrow: 'Your action plan',
    title: 'Team Member Action Plan',
    note: '“Before Huddles begin” covers the weeks leading up to Week 1, the first Huddle; the Huddle steps repeat weekly across the 8-week activation.',
    steps: [
      { label: 'Before Huddles begin', items: ['Complete the baseline survey.', 'Learn what Frontier Accelerator Motion is and what taking part involves.', 'Bring your questions.'] },
      { label: 'After the first 8 weeks', items: ['Complete the impact survey to show the change from baseline.', 'Share what helped you most.'] },
    ],
    phases: [
      { phase: 'Before each Huddle', items: ['Come prepared to engage and ask questions.', 'Bring real scenarios, deals, workflows or tasks.', 'Connect the topic to current work.'] },
      { phase: 'During each Huddle', items: ['Try the experience.', 'Share what worked and what did not.', 'Help peers learn from what worked for you.'] },
      { phase: 'After each Huddle', items: ['Commit to one or two go-dos.', 'Apply them in the flow of work.', 'Bring your learning back to a future Huddle.', 'Answer the weekly usefulness question.'] },
    ],
  },
};

// Tailwind needs literal class names, so column counts map to fixed classes.
const timelineColumns: Record<number, string> = { 2: 'md:grid-cols-2', 3: 'md:grid-cols-3' };
const rhythmColumns: Record<number, string> = { 3: 'lg:grid-cols-3', 4: 'lg:grid-cols-4' };

function GetReadyTimeline({ plan }: { plan: RoleActionPlan }) {
  return <section data-tour="huddle-onboarding-timeline">
    <p className="text-xs font-bold uppercase tracking-[.14em] text-[#0A6BBA]">{plan.eyebrow}</p>
    <h2 className="mt-2 text-3xl font-semibold tracking-tight text-[#16233A]">{plan.title}</h2>
    <p className="mt-2 max-w-3xl text-sm leading-6 text-[#647185]">{plan.note}</p>
    {/* One card per milestone, styled like the Weekly rhythm cards below so the two sections read as a set. */}
    <ol className={`mt-6 grid gap-4 ${timelineColumns[plan.steps.length] ?? 'md:grid-cols-3'}`}>
      {plan.steps.map((step) => <li key={step.label} className="flex flex-col rounded-[20px] border border-[#E0E7ED] bg-white p-5 shadow-[0_8px_24px_rgba(22,35,58,.04)] md:p-6">
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#E2F1F9] text-[#0A6BBA]" aria-hidden="true"><CalendarDays className="h-4 w-4" /></span>
          <h3 className="text-lg font-semibold text-[#16233A]">{step.label}</h3>
        </div>
        <ul className="mt-4 space-y-2.5">{step.items.map((item) => <li key={item} className="flex gap-2 text-sm text-[#5C697D]"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#0A6BBA]" />{item}</li>)}</ul>
      </li>)}
    </ol>
  </section>;
}

function WeeklyRhythm({ plan }: { plan: RoleActionPlan }) {
  const { phases } = plan;
  return <section data-tour="huddle-onboarding-rhythm">
    <p className="text-xs font-bold uppercase tracking-[.14em] text-[#0A6BBA]">Weekly rhythm</p>
    <h2 className="mt-2 text-3xl font-semibold tracking-tight text-[#16233A]">Before, during, and after each Huddle</h2>
    <p className="mt-2 max-w-2xl text-sm leading-6 text-[#647185]">Keep the flow simple and repeatable. Each Huddle should pick up from the last one and leave the team with something practical to try.</p>
    <ol className={`mt-6 grid overflow-hidden rounded-[20px] border border-[#E0E7ED] bg-white divide-y divide-[#E6ECF1] lg:divide-x lg:divide-y-0 ${rhythmColumns[phases.length] ?? 'lg:grid-cols-4'}`}>
      {phases.map((phase, index) => <li key={phase.phase} className="p-5 md:p-6">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-lg font-semibold text-[#16233A]">{phase.phase}</h3>
          {index < phases.length - 1 && <ChevronRight className="hidden h-5 w-5 shrink-0 text-[#0A6BBA] lg:block" aria-hidden="true" />}
        </div>
        <ul className="mt-4 space-y-2.5">{phase.items.map((item) => <li key={item} className="flex gap-2 text-sm text-[#5C697D]"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#0A6BBA]" />{item}</li>)}</ul>
      </li>)}
    </ol>
  </section>;
}

function ThinkFeelDo() {
  const nodes = [
    { label: 'THINK', title: 'Adopt a Frontier Mindset', detail: 'Be curious, adaptive, human-centered, and outcome-oriented. See AI as a transformation lever and learn as Customer Zero.', color: '#8DC8E8', text: '#184C6A', pos: 'left-1/2 top-0 -translate-x-1/2' },
    { label: 'DO', title: 'Apply AI in Real Work', detail: 'Practice inside real workflows, use useful prompts, experiment with the team, and build reusable patterns.', color: '#0A6BBA', text: '#FFFFFF', pos: 'right-0 bottom-3' },
    { label: 'FEEL', title: 'Build Confidence', detail: 'Share wins, lessons, and friction. Repeated practice builds confidence, momentum, and clarity.', color: '#92D3C6', text: '#224E46', pos: 'left-0 bottom-3' },
  ];

  return <section className="space-y-6">
    <div className="max-w-3xl">
      <span className="inline-flex rounded-md bg-[#E2F1F9] px-2.5 py-1 text-xs font-semibold text-[#0A6BBA]">Think · Feel · Do</span>
      <h2 className="mt-3 text-2xl font-semibold tracking-tight text-[#16233A] md:text-3xl">Building AI Fluency in the Flow of Work</h2>
      <p className="mt-2 text-sm leading-6 text-[#5C6678]">AI fluency grows through a continuous cycle of mindset, practice, and confidence-building.</p>
    </div>

    <div className="rounded-[28px] border border-[#DDE7EE] bg-gradient-to-br from-[#F9FCFE] via-white to-[#EAF5F1] p-5 shadow-[0_16px_48px_rgba(31,65,98,.08)] md:p-8">
      <div className="mx-auto hidden h-[430px] max-w-[760px] md:block">
        <div className="relative h-full w-full">
          <div className="absolute left-1/2 top-1/2 h-[270px] w-[270px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-[#9FC5DB]" />
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 18, repeat: Infinity, ease: 'linear' }} className="absolute left-1/2 top-1/2 h-[320px] w-[320px] -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-[#D9EAF3] border-r-[#0A6BBA] border-b-[#92D3C6]">
            <span className="absolute left-1/2 top-[-7px] h-3.5 w-3.5 -translate-x-1/2 rounded-full border-2 border-white bg-[#0A6BBA] shadow-[0_0_16px_rgba(10,107,186,.75)]" aria-hidden="true" />
          </motion.div>
          <div className="absolute left-1/2 top-1/2 flex h-36 w-36 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full border border-white bg-white text-center shadow-[0_16px_40px_rgba(42,68,111,.14)]">
            <Repeat2 className="h-6 w-6 text-[#0A6BBA]" />
            <p className="mt-2 text-sm font-semibold text-[#16233A]">Continuous</p>
            <p className="text-xs text-[#6B7789]">learning loop</p>
          </div>
          {nodes.map((node) => <motion.article whileHover={{ scale: 1.04 }} key={node.label} className={`group absolute w-[250px] rounded-[24px] border border-white/70 p-5 shadow-[0_14px_36px_rgba(22,35,58,.12)] ${node.pos}`} style={{ background: node.color, color: node.text }}>
            <p className="text-[11px] font-bold tracking-[.2em] opacity-75">{node.label}</p>
            <h3 className="mt-2 text-lg font-semibold">{node.title}</h3>
            <p className="mt-0 max-h-0 overflow-hidden text-xs leading-5 opacity-0 transition-all duration-300 group-hover:mt-3 group-hover:max-h-32 group-hover:opacity-90">{node.detail}</p>
          </motion.article>)}
          {/* Clockwise cycle arrows (Think -> Do -> Feel -> Think), drawn as arcs on a circle around the
              loop's center so each sits in the gap between two cards and points at the next step. */}
          <svg className="pointer-events-none absolute left-1/2 top-0 h-[430px] w-[400px] -translate-x-1/2" viewBox="0 0 400 430" fill="none" aria-hidden="true">
            <defs>
              {[['think-do', '#0A6BBA'], ['do-feel', '#287C70'], ['feel-think', '#5B93B1']].map(([id, color]) => (
                <marker key={id} id={`tfd-arrow-${id}`} viewBox="0 0 10 10" refX="7" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M1 1 L9 5 L1 9 Z" fill={color} />
                </marker>
              ))}
            </defs>
            <path d="M330.8 84.2 A185 185 0 0 1 367.7 293.2" stroke="#0A6BBA" strokeWidth="2.5" strokeLinecap="round" markerEnd="url(#tfd-arrow-think-do)" />
            <path d="M263.3 388.8 A185 185 0 0 1 136.7 388.8" stroke="#287C70" strokeWidth="2.5" strokeLinecap="round" markerEnd="url(#tfd-arrow-do-feel)" />
            <path d="M32.3 293.2 A185 185 0 0 1 69.2 84.2" stroke="#5B93B1" strokeWidth="2.5" strokeLinecap="round" markerEnd="url(#tfd-arrow-feel-think)" />
          </svg>
        </div>
      </div>
      <div className="grid gap-3 md:hidden">{nodes.map((node, i) => <div key={node.label} className="rounded-2xl p-5" style={{background:node.color,color:node.text}}><div className="flex items-center justify-between"><span className="text-xs font-bold tracking-[.18em]">{node.label}</span><span className="text-lg">{i < 2 ? '↓' : '↻'}</span></div><h3 className="mt-2 font-semibold">{node.title}</h3><p className="mt-2 text-sm leading-6 opacity-90">{node.detail}</p></div>)}</div>
      <div className="mt-5 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 rounded-2xl border border-[#BFDDE9] bg-white/85 px-5 py-4 text-center text-sm font-medium text-[#2A446F]">{['Think influences action', 'Action builds confidence', 'Confidence changes how people feel', 'Feeling confident changes how teams think and work next'].map((statement, i) => <span key={statement} className="flex items-center gap-x-3">{i > 0 && <span className="text-[#9FC5DB]" aria-hidden="true">|</span>}{statement}</span>)}</div>
    </div>
  </section>;
}

const huddleJourneyStages = [
  { when: 'Before Week 1', stage: 'Onboarding', focus: 'Get ready' },
  { when: 'Week 1', stage: 'Orientation', focus: 'Set the why' },
  { when: 'Weeks 2–8', stage: 'Activation', focus: 'Build the habit' },
  { when: 'Week 9', stage: 'Transition', focus: 'Take ownership' },
  { when: 'Weeks 10+', stage: 'Sustain', focus: 'Keep it going' },
];

function HuddleJourney() {
  return <section className="space-y-6">
    <div className="max-w-3xl">
      <p className="text-xs font-bold uppercase tracking-[.16em] text-[#0A6BBA]">Your Huddle Journey</p>
      <h2 className="mt-2 text-3xl font-semibold tracking-tight text-[#16233A] md:text-4xl">From getting ready to making the rhythm your own</h2>
      <p className="mt-2 text-sm leading-6 text-[#647185]">The goal is not simply to complete a set of Huddles. It is to build a team rhythm that continues beyond the guided path.</p>
    </div>
    <ol className="grid overflow-hidden rounded-[20px] border border-[#DDE6EC] bg-white divide-y divide-[#E6ECF1] sm:grid-cols-5 sm:divide-x sm:divide-y-0">
      {huddleJourneyStages.map((step) => <li key={step.stage} className="p-5 md:p-6">
        <p className="text-sm font-semibold text-[#0A6BBA]">{step.when}</p>
        <h3 className="mt-1.5 text-lg font-semibold text-[#16233A]">{step.stage}</h3>
        <p className="mt-2 text-sm text-[#647185]">{step.focus}</p>
      </li>)}
    </ol>
  </section>;
}

function PersonaOnboarding({ persona, onStartRolePath, onAdditionalTopics }: Pick<HuddleOnboardingExperienceProps, 'persona'|'onStartRolePath'|'onAdditionalTopics'>) {
  const [walkthroughOpen, setWalkthroughOpen] = useState(false);
  const p = persona ? personaOnboarding[persona] : null;
  if (!p) return null;
  const walkthrough = persona ? WALKTHROUGH_GUIDES[persona] : undefined;
  return <motion.section initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} className="space-y-9 pb-10">
    <section className="overflow-hidden rounded-[26px] border border-[#DCE6ED] bg-white shadow-[0_14px_40px_rgba(22,35,58,.06)]">
      <div className="grid lg:grid-cols-[1fr_.55fr]">
        <div className="p-7 md:p-9"><div className="flex flex-wrap items-center gap-3"><span className="inline-flex rounded-full bg-[#E2F1F9] px-3 py-1.5 text-xs font-semibold text-[#0A6BBA]">{p.title}</span></div><h1 className="mt-4 text-3xl font-semibold tracking-tight text-[#16233A]">{p.subtitle}</h1><p className="mt-4 max-w-3xl text-sm leading-7 text-[#5F6D80]">{p.role}</p><div className="mt-6 flex flex-wrap items-center gap-3">{'heroCta' in p && <Button data-tour="huddle-onboarding-start" className="bg-[#0A6BBA] hover:bg-[#115EA3]" onClick={onStartRolePath}>{p.heroCta}<ArrowRight className="ml-2 h-4 w-4"/></Button>}{walkthrough && <Button data-tour="huddle-onboarding-walkthrough" variant="outline" className="border-[#0A6BBA] text-[#0A6BBA] hover:bg-[#E2F1F9]" onClick={() => setWalkthroughOpen(true)}><FileImage className="mr-2 h-4 w-4"/>HTML Walkthrough</Button>}</div></div>
        {walkthrough && walkthroughOpen && <HuddleGuideImageDialog title={walkthrough.title} imageSrc={walkthrough.imageSrc} downloadFileName={walkthrough.fileName} onClose={() => setWalkthroughOpen(false)} />}
        <div className="min-h-[230px] bg-[#EDF5F8]"><img src={persona === 'manager' ? IMAGES.manager : persona === 'facilitator' ? IMAGES.facilitator : IMAGES.member} alt="Team collaborating during practical work" className="h-full w-full object-cover" /></div>
      </div>
    </section>
    <section data-tour="huddle-onboarding-helps"><p className="text-xs font-bold uppercase tracking-[.14em] text-[#0A6BBA]">How this app helps</p><div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-4">{p.cards.map(([title,items],index)=><article key={title} className="rounded-[20px] border border-[#E0E7ED] bg-white p-5 shadow-[0_8px_24px_rgba(22,35,58,.05)]"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#E2F1F9] text-sm font-bold text-[#0A6BBA]">{index+1}</div><h3 className="mt-4 text-lg font-semibold text-[#16233A]">{title}</h3><ul className="mt-3 space-y-2">{items.map(i=><li key={i} className="flex gap-2 text-sm text-[#5C697D]"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#287C70]"/>{i}</li>)}</ul></article>)}</div></section>
    {persona && <><GetReadyTimeline plan={roleActionPlans[persona]} /><WeeklyRhythm plan={roleActionPlans[persona]} /></>}
    <section className="grid overflow-hidden rounded-[24px] border border-[#DCE6ED] bg-white shadow-[0_8px_24px_rgba(22,35,58,.05)] lg:grid-cols-[1.35fr_1fr]">
      <div className="p-7 md:p-9">
        <p className="text-xs font-bold uppercase tracking-[.14em] text-[#0A6BBA]">
          Success looks like
        </p>
        <h2 className="mt-2 text-2xl font-semibold tracking-tight text-[#16233A]">
          A strong team rhythm looks like this
        </h2>
        <ul className="mt-5 space-y-3.5">
          {teamRhythmSuccess.map((s) => (
            <li key={s} className="flex gap-3 text-sm text-[#5C697D]">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#0A6BBA]" />
              {s}
            </li>
          ))}
        </ul>
      </div>

      <div
        data-tour="huddle-onboarding-continue"
        className="flex flex-col justify-center border-t border-[#E6ECF1] bg-[#F8F7F5] p-7 md:p-9 lg:border-l lg:border-t-0"
      >
        <p className="text-xs font-bold uppercase tracking-[.14em] text-[#0A6BBA]">
          Ready to continue?
        </p>
        <h2 className="mt-2 text-2xl font-semibold tracking-tight text-[#16233A]">
          Move from onboarding into practice
        </h2>
        <p className="mt-2 text-sm leading-6 text-[#647185]">
          Continue into your role path or explore additional topics when you are ready.
        </p>
        <div className="mt-5 flex flex-wrap gap-2">
          <Button
            className="bg-[#0A6BBA] hover:bg-[#115EA3]"
            onClick={onStartRolePath}
          >
            {p.primary}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            className="bg-white"
            onClick={onAdditionalTopics}
          >
            Explore All Topics
          </Button>
        </div>
      </div>
    </section>
    <HuddleResourcesSection />
  </motion.section>;
}

export function HuddleOnboardingExperience({ persona, onSelectPersona, onStartRolePath, onAdditionalTopics }: HuddleOnboardingExperienceProps) {
  if (persona) return <PersonaOnboarding persona={persona} onStartRolePath={onStartRolePath} onAdditionalTopics={onAdditionalTopics} />;

  return <motion.section initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} className="space-y-12 pb-12">
    {/* Primary landing hero: explain the value first, then offer immediate ways to start. */}
    <section className="relative overflow-hidden rounded-[28px] border border-[#C9DDE9] bg-white shadow-[0_18px_54px_rgba(31,65,98,.10)]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_85%_20%,rgba(146,211,198,.24),transparent_34%),radial-gradient(circle_at_8%_88%,rgba(141,200,232,.20),transparent_30%)]" />
      <div className="relative grid min-h-[390px] lg:grid-cols-[1.08fr_.92fr]">
        <div className="flex flex-col justify-center p-7 md:p-10 lg:p-12">
          <span className="inline-flex w-fit items-center rounded-full border border-[#CBE3F1] bg-[#E2F1F9] px-3 py-1.5 text-xs font-semibold text-[#0A6BBA]">
            <Sparkles className="mr-1.5 h-3.5 w-3.5" />Frontier Accelerator
          </span>

          <h1 className="mt-5 max-w-3xl text-4xl font-semibold tracking-[-.035em] text-[#16233A] md:text-5xl lg:text-[52px] lg:leading-[1.06]">
            Build AI fluency in the Flow of Work
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-[#5C697D] md:text-lg md:leading-8">
            Frontier Accelerator helps teams apply AI to real work through guided Huddles, shared practice, and repeatable workflow habits.
          </p>

          <div className="mt-7 flex flex-wrap gap-3">
            <Button size="lg" className="bg-[#0A6BBA] px-5 hover:bg-[#115EA3]" onClick={()=>document.getElementById('choose-experience')?.scrollIntoView({behavior:'smooth'})}>
              Select your huddle role<ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="border-[#BFD6E5] bg-white/90 text-[#2A446F] hover:bg-[#F4F9FC]" onClick={()=>document.getElementById('how-huddles-work')?.scrollIntoView({behavior:'smooth'})}>
              How Huddles work
            </Button>
          </div>

          <div className="mt-8 flex flex-wrap gap-2.5">
            {['30 minute Huddles','Role-based paths','Real workflow practice','Team learning rhythm'].map(item=><span key={item} className="rounded-full border border-[#D8E5ED] bg-white/80 px-3 py-1.5 text-xs font-medium text-[#526176] shadow-sm">{item}</span>)}
          </div>
        </div>

        {/* Immediate quick-start panel keeps a meaningful action above the fold. */}
        <div className="flex items-center border-t border-[#E1E9EF] bg-gradient-to-br from-[#F7FBFD]/90 to-[#EAF5F1]/90 p-6 md:p-8 lg:border-l lg:border-t-0 lg:p-9">
          <div data-tour="huddle-agents" className="w-full rounded-[24px] border border-white/80 bg-white/90 p-6 shadow-[0_16px_40px_rgba(42,68,111,.10)] backdrop-blur">
            <p className="text-[11px] font-bold uppercase tracking-[.16em] text-[#0A6BBA]">Top 5 Agents</p>
            <h2 className="mt-2 text-xl font-semibold tracking-tight text-[#16233A]">Meet the agents that help you get work done</h2>
            <p className="mt-2 text-sm leading-5 text-[#647185]">Explore the core AI agents used across Frontier Accelerator. Each agent supports a different part of your workflow, from research and preparation to execution and follow-through.</p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {topAgents.map((agent,i)=>{
                const wide=i===topAgents.length-1 && topAgents.length%2===1;
                return <motion.article whileHover={{y:-2}} key={agent.name} className={`flex rounded-[14px] border border-[#DEE6EC] bg-white px-3.5 py-3 shadow-[0_6px_18px_rgba(22,35,58,.04)]${wide ? " col-span-2 flex-row items-center gap-4" : " flex-col gap-2"}`}>
                  <div className="flex shrink-0 items-center gap-2.5">
                    <img src={agent.logo} alt="" loading="lazy" className="h-9 w-9 shrink-0 rounded-full object-cover shadow-sm"/>
                    <div className="min-w-0"><h3 className="text-[11px] font-semibold uppercase leading-4 tracking-[.08em] text-[#5F6D80]">{agent.name}</h3><p className="text-sm font-semibold leading-5 text-[#16233A]">{agent.label}</p></div>
                  </div>
                  <p className={`text-xs leading-4 text-[#5F6D80]${wide ? " border-l border-[#E3EAF0] pl-4" : ""}`}>{agent.description}</p>
                </motion.article>;
              })}
            </div>
          </div>
        </div>
      </div>
    </section>

    {/* Rich role cards remain available for users who want more context before choosing. */}
    <section id="choose-experience" data-tour="huddle-experience" className="scroll-mt-24 space-y-5">
      <div className="max-w-3xl">
        <p className="text-xs font-bold uppercase tracking-[.16em] text-[#0A6BBA]">Select your huddle role</p>
        <h2 className="mt-2 text-3xl font-semibold tracking-tight text-[#16233A] md:text-4xl">Choose how you want to use Huddles</h2>
        <p className="mt-2 text-sm leading-6 text-[#647185]">Select the experience that best matches your role in the Huddle motion. You can switch later.</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        {personas.map(p=><motion.article whileHover={{y:-4}} key={p.id} className="group flex overflow-hidden rounded-[24px] border border-[#DEE5EC] bg-white shadow-[0_12px_34px_rgba(22,35,58,.06)] lg:min-h-[500px] lg:flex-col">
          <div className="relative h-44 overflow-hidden">
            <img src={p.image} alt={`${p.title} experience focused on team collaboration`} className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"/>
            <div className="absolute inset-0 bg-gradient-to-t from-[#16233A]/38 via-transparent to-transparent"/>
            <div className="absolute bottom-4 left-4 flex h-10 w-10 items-center justify-center rounded-xl bg-white/95 shadow"><p.icon className="h-5 w-5" style={{color:p.accent}}/></div>
          </div>
          <div className="flex flex-1 flex-col p-5 md:p-6">
            <h3 className="text-xl font-semibold text-[#16233A]">{p.title}</h3>
            <p className="mt-1 text-base font-medium text-[#2A446F]">{p.headline}</p>
            <p className="mt-3 text-sm leading-6 text-[#667387]">{p.body}</p>
            <div className="mt-5 space-y-2">{p.helps.slice(0,3).map(x=><div key={x} className="flex gap-2 text-sm text-[#485467]"><Check className="mt-0.5 h-4 w-4 shrink-0 text-[#287C70]"/>{x}</div>)}</div>
            <div className="mt-auto pt-6">
              <Button className="w-full bg-[#0A6BBA] hover:bg-[#115EA3]" onClick={()=>onSelectPersona(p.id)}>{p.cta}<ArrowRight className="ml-2 h-4 w-4"/></Button>
            </div>
          </div>
        </motion.article>)}
      </div>
    </section>

    <div id="how-huddles-work" className="scroll-mt-24"><HuddleJourney /></div>

    <section className="overflow-hidden rounded-[28px] border border-[#DCE6ED] bg-gradient-to-br from-[#F7FBFD] via-white to-[#EDF7F2] shadow-[0_14px_42px_rgba(22,35,58,.06)]"><div className="grid lg:grid-cols-[1.05fr_.95fr]"><div className="p-7 md:p-10"><p className="text-xs font-bold uppercase tracking-[.16em] text-[#0A6BBA]">What is Frontier Accelerator?</p><h2 className="mt-3 text-3xl font-semibold text-[#16233A]">A practical path from AI awareness to adoption</h2><p className="mt-5 max-w-2xl text-base leading-8 text-[#637085]">Frontier Accelerator helps teams adopt AI through structured conversations, guided practice, and real-world application.</p><p className="mt-3 max-w-2xl text-base leading-8 text-[#637085]">Rather than learning tools in isolation, team members learn how AI supports the workflows they already use every day.</p><div className="mt-7 rounded-2xl border border-[#C5DFF0] bg-white p-5 shadow-sm"><div className="flex gap-4"><div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#0A6BBA] text-white"><Lightbulb className="h-5 w-5"/></div><div><p className="font-semibold text-[#2A446F]">The motion principle</p><p className="mt-2 text-sm leading-6 text-[#657286]">Start with the job to be done, then apply the right AI experience to improve the workflow.</p></div></div></div></div><div className="border-t border-[#E2E9EE] p-7 md:p-10 lg:border-l lg:border-t-0"><h3 className="text-xl font-semibold text-[#16233A]">Why it exists</h3><div className="mt-6 grid gap-4 sm:grid-cols-2">{whyItExists.map(([title,body,Icon])=><article key={title} className="rounded-[20px] border border-[#DDE6EC] bg-white/75 p-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#E2F1F9] p-2.5"><Icon className="h-5 w-5 text-[#0A6BBA]"/></div><h4 className="font-semibold text-[#16233A]">{title}</h4></div><p className="mt-4 text-sm leading-6 text-[#637085]">{body}</p></article>)}</div></div></div></section>

    <ThinkFeelDo />

        <section data-tour="huddle-journey" className="space-y-5"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-[#0A6BBA]">Learning Journey</p><h2 className="mt-2 text-3xl font-semibold text-[#16233A]">One motion. Three connected steps.</h2><p className="mt-2 text-sm text-[#647185]">Move from understanding the motion to role-based practice, then keep expanding through self-directed topics.</p></div><div className="relative rounded-[28px] border border-[#DDE6EC] bg-white p-6 md:p-8"><div className="absolute bottom-16 left-[12%] right-[12%] top-16 hidden rounded-full border-2 border-dashed border-[#C7DDE8] lg:block"/><div className="relative grid gap-4 lg:grid-cols-3">{journeySteps.map(([n,title,purpose,,outcome,Icon,surface],i)=><motion.article whileHover={{y:-4}} key={title} className="relative rounded-[22px] border border-[#DDE5EB] bg-white p-5 shadow-[0_10px_28px_rgba(22,35,58,.06)]"><div className="flex items-center justify-between"><div className="flex h-11 w-11 items-center justify-center rounded-xl" style={{background:surface}}><Icon className="h-5 w-5 text-[#0A6BBA]"/></div><span className="text-xs font-bold tracking-[.14em] text-[#8390A0]">STEP {n}</span></div><h3 className="mt-5 text-xl font-semibold text-[#16233A]">{title}</h3><div className="mt-4 space-y-3"><div><p className="text-[11px] font-bold uppercase tracking-[.14em] text-[#8793A2]">Purpose</p><p className="mt-1 text-sm leading-6 text-[#5F6D80]">{purpose}</p></div><div className="rounded-xl bg-[#F7FAFC] p-3"><p className="text-[10px] font-bold uppercase tracking-[.12em] text-[#8793A2]">Outcome</p><p className="mt-1 text-sm font-medium leading-5 text-[#2A446F]">{outcome}</p></div></div>{i<2 && <div className="absolute -right-3 top-1/2 z-10 hidden h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full border bg-white text-[#0A6BBA] shadow lg:flex">→</div>}</motion.article>)}</div></div></section>

    <section className="grid gap-5 xl:grid-cols-2"><div data-tour="huddle-readiness" className="overflow-hidden rounded-[26px] border border-[#DCE5EC] bg-white"><div className="bg-gradient-to-r from-[#EEF7FC] to-white p-7"><p className="text-xs font-bold uppercase tracking-[.16em] text-[#0A6BBA]">Before you begin</p><h2 className="mt-2 text-2xl font-semibold text-[#16233A]">Readiness checklist</h2><p className="mt-2 text-sm text-[#647185]">Complete these steps before your first role-based Huddle.</p></div><div className="grid gap-3 p-6 sm:grid-cols-2">{readiness.map(([title,step])=><div key={title} className="flex gap-3 rounded-2xl border border-[#E1E7ED] p-4"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#E7F6EA]"><Check className="h-4 w-4 text-[#24863A]"/></div><div><p className="text-sm font-semibold text-[#24344C]">{title}</p><p className="mt-1 text-xs text-[#8793A2]">{step}</p></div></div>)}</div></div><div className="overflow-hidden rounded-[26px] border border-[#DCE5EC] bg-white"><div className="bg-gradient-to-r from-[#F4EEFC] to-[#EEF8F2] p-7"><p className="text-xs font-bold uppercase tracking-[.16em] text-[#5E45A8]">Success looks like</p><h2 className="mt-2 text-2xl font-semibold text-[#16233A]">Practical, repeatable adoption</h2><p className="mt-2 text-sm text-[#647185]">The motion is successful when team members change how work gets done.</p></div><div className="grid gap-3 p-6 sm:grid-cols-2">{successSignals.map(([title,body,Icon],i)=><div key={title} className={`${i===4?'sm:col-span-2':''} flex gap-3 rounded-2xl border border-[#E1E7ED] p-4`}><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#F0E9FA]"><Icon className="h-4 w-4 text-[#6743B5]"/></div><div><p className="text-sm font-semibold text-[#24344C]">{title}</p><p className="mt-1 text-xs leading-5 text-[#647185]">{body}</p></div></div>)}</div></div></section>

    <section className="rounded-[28px] border border-[#C9DDE9] bg-gradient-to-br from-[#193B63] to-[#2A446F] p-7 text-white md:p-9"><div className="max-w-3xl"><p className="text-xs font-bold uppercase tracking-[.16em] text-[#BFE2F5]">Weekly Huddle Rhythm</p><h2 className="mt-2 text-3xl font-semibold">A continuous loop from reflection to action</h2><p className="mt-2 text-sm leading-6 text-white/70">Each Huddle picks up where the previous one ended. Teams reflect, practice, commit, and bring real examples back into the next conversation.</p></div><div className="mx-auto mt-8 hidden h-[500px] max-w-[780px] lg:block"><div className="relative h-full"><motion.div animate={{rotate:360}} transition={{duration:34,repeat:Infinity,ease:'linear'}} className="absolute left-1/2 top-1/2 h-[300px] w-[300px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-white/35"/><div className="absolute left-1/2 top-1/2 flex h-40 w-40 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full border border-white/20 bg-white/10 text-center backdrop-blur"><Repeat2 className="h-6 w-6 text-[#92D3C6]"/><p className="mt-2 text-sm font-semibold">Team rhythm</p><p className="mt-1 px-3 text-xs leading-5 text-white/65">Learn, apply, bring back, repeat.</p></div>{rhythm.map(([title,body],i)=>{const positions=['left-1/2 top-0 -translate-x-1/2','right-[2%] top-[22%]','right-[8%] bottom-[10%]','left-1/2 bottom-0 -translate-x-1/2','left-[8%] bottom-[10%]','left-[2%] top-[22%]'];return <motion.div whileHover={{scale:1.04}} key={title} className={`absolute w-[205px] rounded-[20px] border border-white/15 bg-white/[.08] p-4 backdrop-blur ${positions[i]}`}><span className="text-[10px] font-bold text-[#92D3C6]">0{i+1}</span><p className="mt-2 font-semibold">{title}</p><p className="mt-1 text-xs leading-5 text-white/65">{body}</p></motion.div>})}</div></div><div className="mt-7 grid gap-3 sm:grid-cols-2 lg:hidden">{rhythm.map(([t,b],i)=><div key={t} className="rounded-2xl border border-white/12 bg-white/[.07] p-4"><span className="text-xs font-bold text-[#92D3C6]">0{i+1}</span><p className="mt-3 font-semibold">{t}</p><p className="mt-2 text-xs leading-5 text-white/70">{b}</p></div>)}</div></section>

    <HuddleResourcesSection />

    {/* End-of-page next step, so the reader does not have to scroll back up to pick a role. */}
    <div className="flex flex-wrap items-center justify-between gap-3">
      {/* A real link, so hovering shows the address in the tooltip and the browser status bar. */}
      <a href="https://www.microsoft.com/en-us/privacy/privacystatement" target="_blank" rel="noopener noreferrer" title="https://www.microsoft.com/en-us/privacy/privacystatement" className="inline-flex h-10 items-center rounded-lg border border-[#DCE6ED] bg-white px-4 text-sm font-semibold text-[#16233A] transition-colors hover:bg-[#F4F9FC]"><ShieldCheck className="mr-2 h-4 w-4 text-[#0A6BBA]" />Privacy</a>
      <Button size="lg" className="bg-[#0A6BBA] px-5 hover:bg-[#115EA3]" onClick={()=>document.getElementById('choose-experience')?.scrollIntoView({behavior:'smooth'})}>
        Select your huddle role<ArrowRight className="ml-2 h-4 w-4" />
      </Button>
    </div>
  </motion.section>;
}
