import type { ReactNode } from "react";
import { Bot, CalendarDays, Clock, Download, ListChecks, Loader2, Target } from "lucide-react";
import { cn } from "@/lib/utils";
import { mapHuddleCatalogItemToCard } from "../../mappers";
import type { HuddleCatalogItemResponse, HuddleVoteResponse } from "../../types";
import { HuddleVoteControls } from "../catalog";

interface RecommendedPathCardProps {
  week: number;
  huddle: HuddleCatalogItemResponse;
  customized: boolean;
  selected: boolean;
  vote?: HuddleVoteResponse;
  votePending: boolean;
  managementMenu: ReactNode;
  /** Lifts this card's action layer above the sibling cards while its menu is open. */
  managementMenuOpen?: boolean;
  /** Passing null deselects (used when re-clicking the already-selected card). */
  onSelect: (externalId: string | null, placementExternalId?: string | null) => void;
  onVote: (externalId: string, value: -1 | 1 | null) => void;
  htmlExportPending: boolean;
  /** True while any week card is downloading, so downloads never overlap. */
  htmlExportDisabled: boolean;
  onExportHtml: () => void;
  /** Marks this card's HTML and vote controls as walkthrough targets (first card only). */
  tourFirst?: boolean;
}

function agentLabel(names: string[]): string {
  return names.length === 0 ? "None" : names.join(", ");
}

export function RecommendedPathCard({
  week,
  huddle,
  customized,
  selected,
  vote,
  votePending,
  managementMenu,
  managementMenuOpen = false,
  onSelect,
  onVote,
  htmlExportPending,
  htmlExportDisabled,
  onExportHtml,
  tourFirst = false,
}: RecommendedPathCardProps) {
  const card = mapHuddleCatalogItemToCard(huddle);

  return (
    <article
      className={cn(
        "group relative grid grid-cols-[58px_minmax(0,1fr)] items-start gap-3 rounded-xl border bg-white p-4 shadow-sm transition-all duration-200 before:absolute before:-bottom-4 before:left-[39px] before:top-8 before:w-px before:bg-[#C7E0F4] last:before:hidden sm:grid-cols-[58px_minmax(0,1fr)_auto]",
        managementMenuOpen && "z-50",
        selected
          ? "border-[#0F6CBD] bg-[#0F6CBD]/[0.035] ring-2 ring-[#0F6CBD]/15"
          : "border-[#E1DFDD] hover:-translate-y-0.5 hover:border-[#0F6CBD]/60 hover:bg-[#F5F9FF] hover:shadow-md",
      )}
    >
      <div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-full bg-[#0F6CBD] text-sm font-bold text-white shadow-sm transition-transform duration-200 group-hover:scale-105">
        W{week}
      </div>

      <button
        type="button"
        className="min-w-0 text-left focus-visible:outline-none"
        onClick={() => onSelect(selected ? null : huddle.externalId, huddle.placementExternalId)}
      >
        <span className="flex flex-wrap items-center gap-2">
          <span className="text-base font-semibold leading-5 text-[#242424] transition-colors group-hover:text-[#115EA3]">
            {card.title}
          </span>
          {customized && (
            <span className="rounded-full border border-[#D83B01]/30 bg-[#FFF4CE] px-2 py-0.5 text-[10px] font-semibold text-[#8A4B08]">
              Customized
            </span>
          )}
        </span>

        <span className="mt-1 block line-clamp-2 text-sm leading-5 text-muted-foreground">
          {card.description ?? "Description unavailable."}
        </span>

        <span className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <CalendarDays className="h-3.5 w-3.5" />Week {week}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" />
            {card.durationMinutes === null ? "Duration unavailable" : `${card.durationMinutes} minutes`}
          </span>
          <span className="flex items-center gap-1">
            <ListChecks className="h-3.5 w-3.5" />{card.activityCount} {card.activityCount === 1 ? "activity" : "activities"}
            {card.featuredActivityCount !== null && card.extendedActivityCount !== null && card.extendedActivityCount > 0
              && <span className="text-[#707070]"> ({card.featuredActivityCount} featured, {card.extendedActivityCount} extended)</span>}
          </span>
          {card.mcemStageLabel && (
            <span className="flex items-center gap-1">
              <Target className="h-3.5 w-3.5" />{card.mcemStageLabel}
            </span>
          )}
        </span>

        <span className="mt-3 block rounded-lg border border-[#C7E0F4] bg-[#F5F9FF] px-3 py-2.5">
          <span className="grid min-w-0 grid-cols-1 gap-3 sm:grid-cols-[minmax(170px,0.9fr)_minmax(0,1.6fr)]">
            <span className="min-w-0">
              <span className="block text-[10px] font-semibold uppercase tracking-wide text-[#616161]">Primary AI Tool</span>
              <span className="mt-1 block truncate whitespace-nowrap text-sm font-semibold text-[#0F6CBD]">
                <Bot className="mr-1 inline h-3.5 w-3.5" />{agentLabel(card.primaryAgentNames)}
              </span>
            </span>
            <span className="min-w-0 border-t border-[#D6E7F7] pt-3 sm:border-l sm:border-t-0 sm:pl-4 sm:pt-0">
              <span className="block text-[10px] font-semibold uppercase tracking-wide text-[#616161]">Secondary AI Tools</span>
              <span className="mt-1 block truncate whitespace-nowrap text-sm text-[#424242]">
                {agentLabel(card.secondaryAgentNames)}
              </span>
            </span>
          </span>
        </span>
      </button>

      <div className="col-span-2 flex items-center justify-end gap-1 pt-1 sm:col-span-1 sm:pt-0">
        <button
          type="button"
          data-tour={tourFirst ? "huddle-week-html" : undefined}
          disabled={htmlExportDisabled}
          onClick={(event) => { event.stopPropagation(); onExportHtml(); }}
          className="inline-flex h-8 items-center gap-1 rounded-md border border-border bg-white px-2 text-xs font-semibold text-[#242424] transition-colors hover:bg-[#F5F9FF] disabled:opacity-50"
          title={`Download ${card.title} as HTML`}
          aria-label={`Download ${card.title} as HTML`}
          aria-busy={htmlExportPending}
        >
          {htmlExportPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}HTML
        </button>
        <HuddleVoteControls
          tour={tourFirst}
          huddleName={card.title}
          vote={vote}
          disabled={votePending}
          onVote={(value) => onVote(huddle.externalId, value)}
        />
        {managementMenu}
      </div>
    </article>
  );
}
