import { useState } from "react";
import { Download, RefreshCcw, Route } from "lucide-react";
import { ErrorState } from "@/components/feedback/ErrorState";
import { LoadingSpinner } from "@/components/feedback/LoadingSpinner";
import type { HuddleCatalogItemResponse, HuddlePlanResponse, HuddleVoteResponse } from "../../types";
import { ComingSoonWeekCard } from "./ComingSoonWeekCard";
import { RecommendedPathCard } from "./RecommendedPathCard";
import { RolePathWeekMenu } from "./RolePathWeekMenu";

/**
 * Week numbers are read from the plan the API returns, never assumed. The workbook defines a role
 * path as a contiguous run starting at W1, and the count differs only if the workbook changes.
 */
function weeksOf(plan: HuddlePlanResponse): number[] {
  return plan.items.map((item) => item.week);
}

interface RecommendedPathProps {
  data?: HuddlePlanResponse;
  catalog: HuddleCatalogItemResponse[];
  isLoading: boolean;
  error: Error | null;
  mutationError: Error | null;
  selectedExternalId: string | null;
  /** Which placement of selectedExternalId is showing, disambiguating a topic that repeats
   * across two or three weeks in the same role's path (see the matching HuddleCatalog prop). */
  selectedPlacementExternalId: string | null;
  hasRole: boolean;
  /** Audience role name for display; the response only carries the external ID. */
  roleName?: string | null;
  votes: Map<string, HuddleVoteResponse>;
  votePending: boolean;
  savePending: boolean;
  onSelect: (externalId: string | null, placementExternalId?: string | null) => void;
  onVote: (externalId: string, value: -1 | 1 | null) => void;
  /** The week card whose HTML download is in progress, if any. */
  htmlExportExternalId: string | null;
  onExportHtml: (huddle: HuddleCatalogItemResponse) => void;
  onSave: (plan: HuddlePlanResponse) => void;
  onReset: () => void;
  onRetry: () => void;
}

async function exportPlan(plan: HuddlePlanResponse, roleName?: string | null): Promise<void> {
  const { exportLearningPlanHtml } = await import("../../exports/html");
  exportLearningPlanHtml(plan, { roleName });
}

export function RecommendedPath(props: RecommendedPathProps) {
  const [menuWeek, setMenuWeek] = useState<number | null>(null);

  if (!props.hasRole) {
    return <div className="rounded-xl border border-dashed border-[#8A8886] bg-white px-6 py-10 text-center"><Route className="mx-auto h-8 w-8 text-[#0F6CBD]" /><h3 className="mt-3 text-lg font-semibold">Select an audience to build the Role Path</h3><p className="mt-1 text-sm text-muted-foreground">The recommended Huddles will appear in week order.</p></div>;
  }
  if (props.isLoading) return <LoadingSpinner message="Loading role path..." />;
  if (props.error) return <ErrorState title="Unable to load Role Path" message={props.error.message} onRetry={props.onRetry} />;
  if (!props.data) return null;

  // A role with no weekly path, which is true of All Roles: the workbook gives it additional
  // content but no Weeks 1 to 8. Say so and point at the tab that does have content for it.
  if (props.data.items.length === 0) {
    return <div className="rounded-xl border border-dashed border-[#8A8886] bg-white px-6 py-10 text-center"><Route className="mx-auto h-8 w-8 text-[#8A8886]" /><h3 className="mt-3 text-lg font-semibold">No Role Path for {props.roleName ?? props.data.roleExternalId}</h3><p className="mt-1 text-sm text-muted-foreground">This audience has no weekly Huddle sequence configured. Its Huddles are under All Topics.</p></div>;
  }

  const update = (week: number, action: "up" | "down" | "reset", targetWeek?: number, replacement?: string) => {
    const ordered = [...props.data!.items].sort((left, right) => left.week - right.week);
    const recommendedByPosition = ordered.map((item) => item.recommendedHuddleExternalId);
    const index = ordered.findIndex((item) => item.week === week);
    if (index < 0) return;

    if (action === "reset") {
      const expected = recommendedByPosition[index];
      const huddle = props.catalog.find((item) => item.externalId === (replacement ?? expected));
      if (!huddle) return;
      ordered[index] = { ...ordered[index], huddle };
    } else {
      const weeks = weeksOf(props.data!);
      const targetIndex = targetWeek === undefined ? index + (action === "up" ? -1 : 1) : weeks.indexOf(targetWeek);
      if (targetIndex < 0 || targetIndex >= ordered.length) return;
      const [moved] = ordered.splice(index, 1);
      ordered.splice(targetIndex, 0, moved);
    }

    const weekNumbers = weeksOf(props.data!);
    const items = ordered.map((item, position) => ({
      ...item,
      week: weekNumbers[position],
      recommendedHuddleExternalId: recommendedByPosition[position],
      isCustomized: item.huddle.externalId !== recommendedByPosition[position],
    }));
    props.onSave({ ...props.data!, isCustomized: items.some((item) => item.isCustomized), items });
    setMenuWeek(null);
  };

  // Common weeks with no Huddle yet (Week 9). They render after the real weeks but stay out of
  // weeksOf() and update(), so they can't be moved to, replaced, saved or exported.
  const upcomingWeeks = props.data.upcomingWeeks ?? [];

  return <section className="space-y-4 [font-family:var(--aito-font-sans)]">
    <div className="flex flex-col gap-3 rounded-xl border border-[#C7E0F4] bg-[#F5F9FF] px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><Route className="h-5 w-5 text-[#0F6CBD]" /><h2 className="text-xl font-bold">Role Path</h2>{props.data.isCustomized && <span className="rounded-md bg-[#FFF4CE] px-2 py-1 text-xs font-semibold text-[#8A4B08]">Customized</span>}</div><p className="mt-1 text-sm text-muted-foreground">{props.roleName ?? props.data.roleExternalId} · Weeks {props.data.items[0]?.week ?? 1}–{props.data.items[props.data.items.length - 1]?.week ?? props.data.items.length} · {props.data.items.length} Huddles · 30 minutes each{upcomingWeeks.length > 0 && ` · ${upcomingWeeks.length === 1 ? "Week" : "Weeks"} ${upcomingWeeks.map((entry) => entry.week).join(", ")} coming soon`}</p></div>
      <div data-tour="huddle-path-actions" className="flex shrink-0 flex-wrap gap-2"><button type="button" disabled={!props.data.isCustomized || props.savePending} onClick={props.onReset} className="inline-flex h-9 items-center rounded-md border bg-white px-3 text-sm font-semibold hover:bg-[#E8F2FF] disabled:opacity-40"><RefreshCcw className="mr-2 h-4 w-4" />Reset</button><button type="button" onClick={() => void exportPlan(props.data!, props.roleName)} className="inline-flex h-9 items-center rounded-md bg-[#0F6CBD] px-3 text-sm font-semibold text-white hover:bg-[#115EA3]"><Download className="mr-2 h-4 w-4" />Export Learning Plan</button></div>
    </div>
    {props.mutationError && <p className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">{props.mutationError.message} Refresh the plan before trying again.</p>}
    <div className="space-y-3">{props.data.items.map((item, itemIndex) => <RecommendedPathCard tourFirst={itemIndex === 0} key={`${item.week}-${item.huddle.externalId}`} week={item.week} huddle={item.huddle} customized={item.isCustomized} selected={props.selectedExternalId === item.huddle.externalId && props.selectedPlacementExternalId === (item.huddle.placementExternalId ?? null)} vote={props.votes.get(item.huddle.externalId)} votePending={props.votePending} onSelect={props.onSelect} onVote={props.onVote} htmlExportPending={props.htmlExportExternalId === item.huddle.externalId} htmlExportDisabled={props.htmlExportExternalId !== null} onExportHtml={() => props.onExportHtml(item.huddle)} managementMenuOpen={menuWeek === item.week} managementMenu={
      <RolePathWeekMenu tour={itemIndex === 0} week={item.week} weeks={weeksOf(props.data!)} replacements={Array.from(new Map(props.catalog.filter((candidate) => !props.data!.items.some((existing) => existing.huddle.externalId === candidate.externalId)).map((candidate) => [candidate.externalId, candidate])).values())} isCustomized={item.isCustomized} disabled={props.savePending} open={menuWeek === item.week} onOpenChange={(open) => setMenuWeek(open ? item.week : null)} onMoveToWeek={(targetWeek) => update(item.week, "up", targetWeek)} onReplace={(externalId) => update(item.week, "reset", undefined, externalId)} onReset={() => update(item.week, "reset")} />
    } />)}{upcomingWeeks.map((upcoming, upcomingIndex) => <ComingSoonWeekCard tour={upcomingIndex === 0} key={`upcoming-${upcoming.week}`} upcoming={upcoming} />)}</div>
  </section>;
}
